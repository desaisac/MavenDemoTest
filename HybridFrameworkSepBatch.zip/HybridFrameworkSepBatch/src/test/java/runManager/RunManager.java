package runManager;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;

import lib.Global;
import lib.Report;
import lib.Utility;

public class RunManager {
	

	@Test
	public void run() throws Exception {
		
		

	//public static void main(String[] args) throws FilloException, ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
		
		Report.createHtmlReport();
		String strQuery = "select * from Groups where Run = 'Y'";
		List l_Groups= Utility.readGroups(Global.groupControlFilePath, strQuery);
		
		for(int i=0 ; i<l_Groups.size();i++) {
			
			String strSheetname= l_Groups.get(i).toString();
			String strQuery_Test = "select * from "+ strSheetname +" where Run = 'Y'";
			Recordset rs= Utility.readTestCases(Global.groupControlFilePath, strQuery_Test);
			
			while (rs.next()) {
				Global.gstrID=rs.getField("ID");
				Global.gstrAutomationID = rs.getField("Automation_ID");
				Global.gstrDescription=rs.getField("Description");
				String strComponents=  rs.getField("BatchFile");
				String []  arrComp = strComponents.split("_");
				
				new Utility(Global.gstrBrowserName);
				
				for(int j=0;j<arrComp.length;j++) {
					String clasName=  arrComp[j].split("\\.")[0];
					Global.gstrClassName = clasName;
					String MethodName=  arrComp[j].split("\\.")[1];
					Global.gstrMethodName=MethodName;
					//reflection
					Class cls = Class.forName("pages."+clasName);
					Object obj = cls.newInstance();
					Method m = cls.getMethod(MethodName);
					m.invoke(obj);
				}
				
			}
			
			
		}
		
		Global.report.flush();
		
		

	}

}
