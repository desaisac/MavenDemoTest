package pages;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.codoid.products.exception.FilloException;

import lib.Global;
import lib.TestData;
import lib.Utility;

public class HomePage {
	
	WebDriver driver;
	
	@FindBy(xpath="//a[text()='REGISTER']")
	public WebElement link_FH_Register;
	
	
	@FindBy(xpath="//input[@name='userName']")
	public WebElement edt_FH_UserName;
	
	@FindBy(xpath="//input[@name='password']")
	public WebElement edt_FH_Password;
	
	@FindBy(xpath="//input[@name='login']")
	public WebElement btn_FH_signIn;
	
	
	
	
	
	
	
	public HomePage(){
		driver = Utility.returnDriver();
		PageFactory.initElements(driver, this);
	}
	
	
	//Business components
	public void home() throws FilloException, IOException {
		
		Global.gstrObjDataMap=TestData.readTestData(Global.gstrID, Global.gstrClassName, Global.gstrMethodName);
		driver.get(Global.appURL);
		
		Utility.clickElement(link_FH_Register, "Register link", "FH_RegisterClick");
		Utility.enterText(edt_FH_UserName, "UserName", "FH_UserNameSet");
		Utility.enterText(edt_FH_Password, "password", "FH_PasswordSet");
		Utility.clickElement(btn_FH_signIn, "Sign In", "FH_signInClick");
		
		
		
		
	}
	

}
