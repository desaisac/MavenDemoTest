package lib;

public class ApplicationUtility {

}
