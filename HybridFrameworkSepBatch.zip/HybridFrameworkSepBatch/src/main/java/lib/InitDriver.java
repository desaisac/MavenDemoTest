package lib;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class InitDriver {
	
	private static WebDriver driver;
	
	private InitDriver() {
		
	}
	
	
	/**
	 * @author dharm
	 * Function Name : getDriverInstance(String strBrowserName)
	 */
	public static WebDriver getDriverInstance(String strBrowserName) {
		
		if (driver==null) {
			
			if(strBrowserName.contentEquals(Global.gstrBrowserName)) {
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
			}
			else if(strBrowserName.contentEquals(Global.gstrBrowserName)){
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
			}
			
		}
		return driver;
		
	}

}
