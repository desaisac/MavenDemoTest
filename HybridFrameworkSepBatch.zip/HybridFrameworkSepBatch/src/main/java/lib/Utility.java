package lib;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;


public class Utility {
	
	public static WebDriver driver;
	
	public Utility(String strBrowserName) {
		driver= InitDriver.getDriverInstance(strBrowserName);
		Global.logger = Global.report.createTest(Global.gstrAutomationID, Global.gstrDescription);
	}
	
	
	//its just supply driver to pages class
	public static WebDriver returnDriver() {
		return driver;
		
	}
	

	
	/**
	 * @author dharm
	 * Function Name : getRecordusingFillo(String FilePath , String strQuery)
	 */
	public static Recordset getRecordusingFillo(String FilePath , String strQuery) throws FilloException {
		
		Fillo f =null ;
		Connection con=null;
		Recordset rs = null;
		
		f = new Fillo();
		con = f.getConnection(FilePath);
		rs= con.executeQuery(strQuery);
		
		if(rs!=null) {
			return rs;
		}
		
		return rs;
		
	}
	
	/**
	 * @author dharm
	 * Function Name : readGroups(String FilePath , String strQuery)
	 * @throws FilloException 
	 */
	public static List readGroups(String FilePath , String strQuery) throws FilloException  {
		
		ArrayList l = new ArrayList();
		Recordset rs = Utility.getRecordusingFillo(FilePath, strQuery);
		
		while(rs.next()) {
			l.add(rs.getField("Groups"));
		}
		
		
		return l;
		
	
	}
	/**
	 * @author dharm
	 * Function Name : readGroups(String FilePath , String strQuery)
	 * @throws FilloException 
	 */
	public static Recordset readTestCases(String FilePath , String strQuery) throws FilloException {
		Recordset rs = Utility.getRecordusingFillo(FilePath, strQuery);
		return rs;
			
	}
	
	
	/**
	 * @author dharm
	 * Function Name : clickElement(WebElement ele , String label , String colName)
	 * @throws IOException 
	 * @throws FilloException 
	 */
	public static String clickElement(WebElement ele , String label , String colName) throws IOException {
		
		String s="";
		String strVar = TestData.readTestdataValue(colName);
		if(strVar.contentEquals("SKIP") || strVar.contentEquals("")) {
			return  s;
		}
		
		
		try {
			ele.click();
			Report.writeHtmlLogs("PASS", "Sucessfully click on " + label);
			Report.takeScreenShot("PASS", "");
		}
		catch(Exception e) {
			Report.writeHtmlLogs("FAIL", "Failed to click on " + label + " --> " + e.getMessage());
			Report.takeScreenShot("FAIL", "");
		}
			
		return s;
		
		
		
	}
	
	
	/**
	 * @author dharm
	 * Function Name :  enterText(WebElement ele , String label , String colName)
	 * @return 
	 * @throws IOException 
	 * @throws FilloException 
	 */
	public static String enterText(WebElement ele , String label , String colName) throws IOException {
		
		String s="";
		String strVar = TestData.readTestdataValue(colName);
		if(strVar.contentEquals("SKIP") || strVar.contentEquals("")) {
			return  s;
		}		
		
		try {
			ele.sendKeys(strVar);
			Report.writeHtmlLogs("PASS", "Sucessfully enter " + strVar + " in " + "text box " + label);
			Report.takeScreenShot("PASS", "");
		}
		catch(Exception e) {
			Report.writeHtmlLogs("FAIL", "Failed to enter " + strVar + " in " + "text box " + label);
			Report.takeScreenShot("FAIL", "");
		}
			
		return s;
		
	}
	
	

}
