package lib;

import java.util.HashMap;
import java.util.Map;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Recordset;

public class TestData {
	
	public static Map readTestData(String id , String Classname , String methodName) throws FilloException {
		
		HashMap m = new HashMap();
		String strFilePath = Global.testArtifacts + Classname +"_TestData.xlsx";
		String strQuery = "select * from " + methodName + " where ID = '" + id + "' ";
		Recordset rs= Utility.getRecordusingFillo(strFilePath, strQuery);
		
		while(rs.next()) {
			for(int i=0;i<rs.getFieldNames().size();i++) {
				String colName=rs.getField(i).name();
				String colValue=rs.getField(i).value();
				m.put(colName, colValue);
			}
		}
		
		return m;	
	}
	
	//+++++++++++++++++++++++++++++++++
	
	public static String readTestdataValue(String colname) {
		
		String strValue= (String) Global.gstrObjDataMap.get(colname.toUpperCase());
		
		
		return strValue;
		
	}

}
